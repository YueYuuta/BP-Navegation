import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { combineLatest, forkJoin, merge } from 'rxjs';
import { NavegationService } from 'src/app/services/navegation.service';
import { HomePageName } from 'src/app/utils/enum/page-main/home-page-name.enum';
import { GeneralData } from 'src/app/utils/enum/sections/genetal-data.enum';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.scss'],
})
export class InicioComponent implements OnInit, AfterViewInit {
  pageName = HomePageName['Datos generales'];
  homePageName;
  pageStatusList: boolean[];
  generalData = GeneralData;
  form1: FormGroup;
  form2: FormGroup;

  constructor(
    private readonly _navigationPages: NavegationService,
    private readonly fb: FormBuilder
  ) {}

  ngAfterViewInit() {
    this.changeEstadoNav();
  }
  ngOnInit(): void {
    this.initHomePageStatus();
    this.initForm1();
    this.initForm2();
    this.observeValuesForms();
  }
  observeValuesForms() {
    const observables = [this.form1.valueChanges, this.form2.valueChanges];
    merge(...observables).subscribe(() => {
      this.evaluatePageStatus();
    });
  }
  initHomePageStatus() {
    this._navigationPages.pageListMain$.subscribe((data) => {
      this.homePageName = data;
    });
  }
  evaluatePageStatus() {
    this.pageStatusList = [];
    this.pageStatusList.push(this.form1.valid);
    this.pageStatusList.push(this.form2.valid);
    const found = !this.pageStatusList.includes(false);
    const send = this.homePageName;
    send[this.pageName] = found;
    this._navigationPages.pageListMain(send);
  }
  get details() {
    return this.form1.get('details') as FormArray;
  }
  get details2() {
    return this.form2.get('details2') as FormArray;
  }
  agregar() {
    const subform = this.fb.group({
      name: ['', Validators.required],
      lastname: ['', Validators.required],
    });
    this.details.push(subform);
  }

  remove(indice: number) {
    this.details.removeAt(indice);
  }

  agregar2() {
    console.log('ta loco he');
    const subform2 = this.fb.group({
      name: ['', Validators.required],
      lastname: ['', Validators.required],
    });
    this.details2.push(subform2);
  }

  remove2(indice: number) {
    this.details2.removeAt(indice);
  }

  private initForm1(): void {
    this.form1 = this.fb.group({
      number1: [null, Validators.required],
      details: this.fb.array([]),
    });
  }

  private initForm2(): void {
    this.form2 = this.fb.group({
      number1: [null, Validators.required],
      details2: this.fb.array([]),
    });
  }
  elemetoHtmlSeleccionado(alias: string) {
    const primer = document.getElementById(alias);
    primer.scrollIntoView({ behavior: 'smooth' });
  }

  changeEstadoNav(): void {
    this._navigationPages.paginaSection$
      // .pipe(takeUntil(this.stop$))
      .subscribe((pagina: string) => {
        this.elemetoHtmlSeleccionado(pagina);
      });
  }
}
